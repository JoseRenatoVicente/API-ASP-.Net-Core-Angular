export interface Venda {

    Id: number;
    ProdutoId: number;
    PedidoId: number;
    Quantidade: number;
    ValorProduto: number;
}
