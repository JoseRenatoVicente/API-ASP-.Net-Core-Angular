﻿namespace TratandoImagens_SQLServer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picImagem = new System.Windows.Forms.PictureBox();
            this.btnCarregarImagem = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnSalvarImagemBD = new System.Windows.Forms.Button();
            this.txtStringConexaoBD = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRetornarImagemBD = new System.Windows.Forms.Button();
            this.txtCodigoImagem = new System.Windows.Forms.TextBox();
            this.txtDescricaoImagem = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAtivar = new System.Windows.Forms.Button();
            this.gdvImagens = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.picImagem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvImagens)).BeginInit();
            this.SuspendLayout();
            // 
            // picImagem
            // 
            this.picImagem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.picImagem.Location = new System.Drawing.Point(22, 114);
            this.picImagem.Name = "picImagem";
            this.picImagem.Size = new System.Drawing.Size(315, 299);
            this.picImagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picImagem.TabIndex = 0;
            this.picImagem.TabStop = false;
            // 
            // btnCarregarImagem
            // 
            this.btnCarregarImagem.Enabled = false;
            this.btnCarregarImagem.Location = new System.Drawing.Point(25, 420);
            this.btnCarregarImagem.Name = "btnCarregarImagem";
            this.btnCarregarImagem.Size = new System.Drawing.Size(312, 38);
            this.btnCarregarImagem.TabIndex = 1;
            this.btnCarregarImagem.Text = "Carregar Imagem ";
            this.btnCarregarImagem.UseVisualStyleBackColor = true;
            this.btnCarregarImagem.Click += new System.EventHandler(this.btnCarregarImagem_Click);
            // 
            // btnSalvarImagemBD
            // 
            this.btnSalvarImagemBD.Enabled = false;
            this.btnSalvarImagemBD.Location = new System.Drawing.Point(352, 420);
            this.btnSalvarImagemBD.Name = "btnSalvarImagemBD";
            this.btnSalvarImagemBD.Size = new System.Drawing.Size(251, 38);
            this.btnSalvarImagemBD.TabIndex = 2;
            this.btnSalvarImagemBD.Text = "Salvar Imagem no Banco de dados";
            this.btnSalvarImagemBD.UseVisualStyleBackColor = true;
            this.btnSalvarImagemBD.Click += new System.EventHandler(this.btnSalvarImagemBD_Click);
            // 
            // txtStringConexaoBD
            // 
            this.txtStringConexaoBD.Location = new System.Drawing.Point(22, 34);
            this.txtStringConexaoBD.Multiline = true;
            this.txtStringConexaoBD.Name = "txtStringConexaoBD";
            this.txtStringConexaoBD.Size = new System.Drawing.Size(508, 53);
            this.txtStringConexaoBD.TabIndex = 3;
            this.txtStringConexaoBD.Text = "Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\f5361091\\Documents\\Cadastro.md" +
                "f;Integrated Security=True;Connect Timeout=30;User Instance=True";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "String de Conexão com o SQL Server";
            // 
            // btnRetornarImagemBD
            // 
            this.btnRetornarImagemBD.Enabled = false;
            this.btnRetornarImagemBD.Location = new System.Drawing.Point(352, 114);
            this.btnRetornarImagemBD.Name = "btnRetornarImagemBD";
            this.btnRetornarImagemBD.Size = new System.Drawing.Size(251, 38);
            this.btnRetornarImagemBD.TabIndex = 5;
            this.btnRetornarImagemBD.Text = "Obter Imagem do Banco de dados";
            this.btnRetornarImagemBD.UseVisualStyleBackColor = true;
            this.btnRetornarImagemBD.Click += new System.EventHandler(this.btnRetornarImagemBD_Click);
            // 
            // txtCodigoImagem
            // 
            this.txtCodigoImagem.Location = new System.Drawing.Point(352, 193);
            this.txtCodigoImagem.Name = "txtCodigoImagem";
            this.txtCodigoImagem.Size = new System.Drawing.Size(242, 22);
            this.txtCodigoImagem.TabIndex = 6;
            // 
            // txtDescricaoImagem
            // 
            this.txtDescricaoImagem.Location = new System.Drawing.Point(352, 247);
            this.txtDescricaoImagem.Multiline = true;
            this.txtDescricaoImagem.Name = "txtDescricaoImagem";
            this.txtDescricaoImagem.Size = new System.Drawing.Size(243, 149);
            this.txtDescricaoImagem.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(352, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Código da Imagem";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(352, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Descrição da Imagem";
            // 
            // btnAtivar
            // 
            this.btnAtivar.Location = new System.Drawing.Point(532, 34);
            this.btnAtivar.Name = "btnAtivar";
            this.btnAtivar.Size = new System.Drawing.Size(58, 53);
            this.btnAtivar.TabIndex = 10;
            this.btnAtivar.Text = "Ativar";
            this.btnAtivar.UseVisualStyleBackColor = true;
            this.btnAtivar.Click += new System.EventHandler(this.btnAtivar_Click);
            // 
            // gdvImagens
            // 
            this.gdvImagens.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.gdvImagens.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdvImagens.Location = new System.Drawing.Point(22, 479);
            this.gdvImagens.Name = "gdvImagens";
            this.gdvImagens.RowTemplate.Height = 24;
            this.gdvImagens.Size = new System.Drawing.Size(576, 161);
            this.gdvImagens.TabIndex = 11;
            this.gdvImagens.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdvImagens_CellClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(617, 652);
            this.Controls.Add(this.gdvImagens);
            this.Controls.Add(this.btnAtivar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDescricaoImagem);
            this.Controls.Add(this.txtCodigoImagem);
            this.Controls.Add(this.btnRetornarImagemBD);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtStringConexaoBD);
            this.Controls.Add(this.btnSalvarImagemBD);
            this.Controls.Add(this.btnCarregarImagem);
            this.Controls.Add(this.picImagem);
            this.Name = "Form1";
            this.Text = "Imagens - SQL Server";
            ((System.ComponentModel.ISupportInitialize)(this.picImagem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvImagens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picImagem;
        private System.Windows.Forms.Button btnCarregarImagem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnSalvarImagemBD;
        private System.Windows.Forms.TextBox txtStringConexaoBD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRetornarImagemBD;
        private System.Windows.Forms.TextBox txtCodigoImagem;
        private System.Windows.Forms.TextBox txtDescricaoImagem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAtivar;
        private System.Windows.Forms.DataGridView gdvImagens;
    }
}

